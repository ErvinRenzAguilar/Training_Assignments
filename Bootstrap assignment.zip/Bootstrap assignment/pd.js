var eamount,disco,tamount;

function dispval() {
    
    var electitem = document.getElementById("ElecItem");  
    eamount = document.getElementById("price").value = electitem.options[electitem.selectedIndex].value; 
        
  }
  function check(disc) {
   disco =disc*eamount;
   document.getElementById("tprice").value=disco;
  }
  function myFunction() {
    var x = document.getElementById("inprice").value;
    tamount=x-disco;
    alert("Order placed. Your change is "+tamount);
  }